package com.example.jogo_humilde;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText entrada;
    TextView saida;
    int numero;
    int tentativas = 0;
    Random gerador = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        entrada = findViewById(R.id.entrada);
        saida = findViewById(R.id.saida);
    }

    public void gerar(View v) {
        tentativas = 0;
        numero = gerador.nextInt(50) + 1;
        saida.setText("Numero gerado!");
        entrada.setText("");

    }

    public void confirma(View v) {
        int digitado = Integer.parseInt(entrada.getText().toString());
        tentativas++;
        if (digitado > numero) {
            saida.setText("O numero é menor");

        } else if (digitado < numero) {
            saida.setText("O numero é maior");

        } else{
            saida.setText("O numero é igual");

        } if (tentativas > 5) {
            Toast.makeText(this, "Acabaram as tentativas", Toast.LENGTH_SHORT).show();
            entrada.setText("");
            saida.setText("");
        }
    }
}


